package q9k.buaa.INIT;

public class Config {
}
