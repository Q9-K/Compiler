package q9k.buaa.Frontend.AST;

public class Stmt implements Syntax{

    private int condition;


    @Override
    public void print() {

    }

    @Override
    public void handleError() {

    }
}
