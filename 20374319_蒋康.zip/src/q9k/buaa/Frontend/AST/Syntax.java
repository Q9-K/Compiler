package q9k.buaa.Frontend.AST;

public interface Syntax {
    public void print();//打印选项
    public void handleError();//出错处理
}
